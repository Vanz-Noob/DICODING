/* eslint-disable linebreak-style */
// membuat varible array dari book dan diisi kosong dan mengkespor modulnya
const books = [];
module.exports = books;
